public class BankAccount {
    private final String accountId;
    private final String bankName;
    private double balance;
    private final SimpleLinkedList<Expenditure> expenditures = new SimpleLinkedList<>();

    public BankAccount(String accountId, String bankName, double balance) {
        this.accountId = accountId;
        this.bankName = bankName;
        this.balance = balance;
    }

    public void addExpenditure(Expenditure e) {
        expenditures.add(e);
    }

    public void deductBalance(double amount) {
        balance -= amount;
    }

    public void addBalance(double amount) {
        balance += amount;
    }

    public String getAccountId() {
        return accountId;
    }

    public double getBalance() {
        return balance;
    }

    @Override
    public String toString() {
        return String.format("%s (%s) Balance: GHS %.2f, Expenditures: %d", accountId, bankName, balance,
                expenditures.size());
    }
}