import java.util.*;

public class BankManager {
    private final Map<String, BankAccount> map = new HashMap<>();

    public void addAccount(BankAccount a) {
        map.put(a.getAccountId(), a);
    }

    public BankAccount getAccount(String id) {
        return map.get(id);
    }

    public Collection<BankAccount> getAllAccounts() {
        return map.values();
    }

    public void printAll() {
        System.out.println("Accounts:");
        map.values().forEach(a -> System.out.println(" - " + a));
    }
}