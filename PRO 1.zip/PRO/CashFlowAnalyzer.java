import java.util.*;

public class CashFlowAnalyzer {
    public void analyze(Collection<Expenditure> exps, Collection<BankAccount> banks) {
        System.out.println("\n--- Cash Flow & Analysis ---");
        Map<String, Double> perMonth = new TreeMap<>();
        exps.forEach(e -> {
            String m = e.getDate().getYear() + "-" + String.format("%02d", e.getDate().getMonthValue());
            perMonth.put(m, perMonth.getOrDefault(m, 0.0) + e.getAmount());
        });
        System.out.println("Monthly burn (by month):");
        perMonth.forEach((k, v) -> System.out.println(k + " => GHS " + String.format("%.2f", v)));
        double total = exps.stream().mapToDouble(Expenditure::getAmount).sum();
        System.out.println("Total spending recorded: GHS " + String.format("%.2f", total));
        double avgMonthly = perMonth.values().stream().mapToDouble(d -> d).average().orElse(0.0);
        System.out.println("Average monthly burn: GHS " + String.format("%.2f", avgMonthly));
        System.out.println("Bank balances:");
        banks.forEach(
                b -> System.out.println(" - " + b.getAccountId() + ": GHS " + String.format("%.2f", b.getBalance())));
        double balances = banks.stream().mapToDouble(BankAccount::getBalance).sum();
        if (avgMonthly > 0) {
            System.out.println(
                    "Estimated runway (months) at current burn: " + String.format("%.1f", balances / avgMonthly));
        } else {
            System.out.println("Insufficient data to forecast runway.");
        }
        double cementSpend = exps.stream().filter(e -> e.getCategory().equalsIgnoreCase("Cement"))
                .mapToDouble(Expenditure::getAmount).sum();
        System.out.println(
                "Material (Cement) spend proportion: " + String.format("%.2f", (cementSpend / total * 100)) + "%");
    }
}