public class CategoryManager {
    private final SimpleSet<String> set = new SimpleSet<>();

    public boolean addCategory(String c) {
        return set.add(c.trim());
    }

    public boolean removeCategory(String c) {
        return set.remove(c);
    }

    public boolean exists(String c) {
        return set.contains(c);
    }

    public void printAll() {
        System.out.println("Categories:");
        for (String s : set.items()) {
            System.out.println(" - " + s);
        }
    }
}