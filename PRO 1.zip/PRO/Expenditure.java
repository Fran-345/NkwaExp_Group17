import java.time.LocalDate;

public class Expenditure {
    private final String code;
    private final double amount;
    private final LocalDate date;
    private final String phase;
    private final String category;
    private final String accountUsed;
    private final String receiptFile;

    public Expenditure(String code, double amount, LocalDate date, String phase, String category, String accountUsed,
            String receiptFile) {
        this.code = code;
        this.amount = amount;
        this.date = date;
        this.phase = phase;
        this.category = category;
        this.accountUsed = accountUsed;
        this.receiptFile = receiptFile;
    }

    public String getCode() {
        return code;
    }

    public double getAmount() {
        return amount;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getPhase() {
        return phase;
    }

    public String getCategory() {
        return category;
    }

    public String getAccountUsed() {
        return accountUsed;
    }

    public String getReceiptFile() {
        return receiptFile;
    }

    @Override
    public String toString() {
        return String.format("[%s] GHS %.2f | %s | %s | %s | account:%s", code, amount, date.toString(), phase,
                category, accountUsed);
    }
}