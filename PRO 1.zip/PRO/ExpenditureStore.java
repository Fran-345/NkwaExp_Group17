import java.util.*;

public class ExpenditureStore {
    private final Map<String, Expenditure> map = new HashMap<>();

    public Expenditure get(String code) {
        return map.get(code);
    }

    public void put(String code, Expenditure e) {
        map.put(code, e);
    }

    public List<Expenditure> values() {
        return new ArrayList<>(map.values());
    }
}