import java.util.*;

public class Graph {
    private final Map<String, Set<String>> adj = new HashMap<>();

    public void addVertex(String v) {
        adj.putIfAbsent(v, new HashSet<>());
    }

    public void addEdge(String a, String b) {
        addVertex(a);
        addVertex(b);
        adj.get(a).add(b);
        adj.get(b).add(a);
    }

    public Set<String> neighbors(String v) {
        return adj.getOrDefault(v, Collections.emptySet());
    }
}