import java.util.*;

public class MinHeapBankMinBalance {
    private final PriorityQueue<BankAccount> pq = new PriorityQueue<>(
            Comparator.comparingDouble(BankAccount::getBalance));
    private final Map<String, BankAccount> map = new HashMap<>();

    public void add(BankAccount a) {
        map.put(a.getAccountId(), a);
        pq.offer(a);
    }

    public void update(BankAccount a) {
        pq.remove(a);
        pq.offer(a);
    }

    public BankAccount peek() {
        return pq.peek();
    }

    public BankAccount get(String accountId) {
        return map.get(accountId); // Retrieve a BankAccount by its ID
    }
}