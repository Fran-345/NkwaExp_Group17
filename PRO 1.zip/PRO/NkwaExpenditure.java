import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;


public class NkwaExpenditure {
    private final Scanner scanner = new Scanner(System.in);
    private final DateTimeFormatter DF = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private final CategoryManager categoryManager = new CategoryManager();
    private final BankManager bankManager = new BankManager();
    private final ExpenditureStore store = new ExpenditureStore();
    private final ReceiptQueue receiptQueue = new ReceiptQueue();
    private final ReceiptStack receiptStack = new ReceiptStack();
    private final MinHeapBankMinBalance notifier = new MinHeapBankMinBalance();
    private final TreeBST tree = new TreeBST();
    private final Graph accountsGraph = new Graph();
    private final SearchSortUtils searchSort = new SearchSortUtils();
    private final CashFlowAnalyzer analyzer = new CashFlowAnalyzer();

    public static void main(String[] args) {
        NkwaExpenditure app = new NkwaExpenditure();
        app.run();
    }

    private void run() {
        seedDemoData();
        boolean running = true;
        while (running) {
            printMainMenu();
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1" -> addExpenditure();
                case "2" -> viewExpenditureByCode();
                case "3" -> manageCategories();
                case "4" -> manageBankAccounts();
                case "5" -> searchAndSortMenu();
                case "6" -> processReceiptQueue();
                case "7" -> processReceiptStack();
                case "8" -> showCashFlowAnalysis();
                case "0" -> running = false;
                default -> System.out.println("Unknown option");
            }
        }
        System.out.println("Goodbye — Nkwa Expenditure System closed.");
    }

    private void printMainMenu() {
        System.out.println("\n=== Nkwa Real Estate - Expenditure Management ===");
        System.out.println("1) Add Expenditure");
        System.out.println("2) View Expenditure by Code");
        System.out.println("3) Category Management");
        System.out.println("4) Bank Accounts");
        System.out.println("5) Search & Sort");
        System.out.println("6) Process Receipt Upload/Review Queue");
        System.out.println("7) Process Receipt Review Stack");
        System.out.println("8) Cash Flow & Analysis");
        System.out.println("0) Exit");
        System.out.print("Select: ");
    }

    private void seedDemoData() {
        categoryManager.addCategory("Cement");
        categoryManager.addCategory("Printing");
        categoryManager.addCategory("TV Adverts");
        categoryManager.addCategory("Labour");

        BankAccount b1 = new BankAccount("ACC001", "Ghana Commercial Bank", 50000.0);
        BankAccount b2 = new BankAccount("ACC002", "Ecobank", 20000.0);
        bankManager.addAccount(b1);
        bankManager.addAccount(b2);
        accountsGraph.addVertex(b1.getAccountId());
        accountsGraph.addVertex(b2.getAccountId());
        accountsGraph.addEdge(b1.getAccountId(), b2.getAccountId());

        addExpenditureInternal(new Expenditure("EXP001", 15000.0, LocalDate.of(2025, 4, 2), "construction", "Cement",
                b1.getAccountId(), "r1.pdf"));
        addExpenditureInternal(new Expenditure("EXP002", 3000.0, LocalDate.of(2025, 4, 10), "marketing", "TV Adverts",
                b2.getAccountId(), "inv23.pdf"));

        notifier.add(b1);
        notifier.add(b2);
    }

    private void addExpenditure() {
        try {
            System.out.print("Enter code: ");
            String code = scanner.nextLine().trim();
            if (store.get(code) != null) {
                System.out.println("Code already exists.");
                return;
            }
            System.out.print("Amount: ");
            double amount = Double.parseDouble(scanner.nextLine().trim());
            if (amount <= 0) {
                System.out.println("Amount must be positive.");
                return;
            }
            System.out.print("Date (yyyy-MM-dd): ");
            LocalDate date = LocalDate.parse(scanner.nextLine().trim(), DF);
            System.out.print("Phase: ");
            String phase = scanner.nextLine().trim();
            System.out.print("Category: ");
            String category = scanner.nextLine().trim();
            if (!categoryManager.exists(category)) {
                System.out.println("Category doesn't exist. Adding it.");
                categoryManager.addCategory(category);
            }
            System.out.print("Account ID: ");
            String accId = scanner.nextLine().trim();
            BankAccount account = bankManager.getAccount(accId);
            if (account == null) {
                System.out.println("Account not found. Aborting.");
                return;
            }
            System.out.print("Receipt filename (optional): ");
            String receiptFile = scanner.nextLine().trim();

            Expenditure e = new Expenditure(code, amount, date, phase, category, accId, receiptFile);
            addExpenditureInternal(e);
            System.out.println("Expenditure added and linked to account " + accId);
        } catch (NumberFormatException | DateTimeParseException | NullPointerException ex) {
            System.out.println("Error adding expenditure: " + ex.getMessage());
        }
    }

    private void addExpenditureInternal(Expenditure e) {
        store.put(e.getCode(), e);
        tree.insert(e);
        BankAccount acc = bankManager.getAccount(e.getAccountUsed());
        if (acc != null) {
            acc.addExpenditure(e);
            acc.deductBalance(e.getAmount());
            notifier.update(acc);
            if (acc.getBalance() < 5000) {
                System.out.println("[ALERT] Account " + acc.getAccountId() + " low on funds: " + acc.getBalance());
            }
        }
        if (e.getReceiptFile() != null && !e.getReceiptFile().isEmpty()) {
            Receipt r = new Receipt(e.getCode(), e.getReceiptFile(), LocalDate.now());
            receiptQueue.enqueue(r);
            receiptStack.push(r);
        }
    }

    private void viewExpenditureByCode() {
        System.out.print("Enter expenditure code: ");
        String code = scanner.nextLine().trim();
        Expenditure e = tree.find(code);
        if (e == null)
            System.out.println("Not found.");
        else
            System.out.println(e);
    }

    private void manageCategories() {
        boolean back = false;
        while (!back) {
            System.out.println("\nCategory Manager\n1) List 2) Add 3) Remove 0) Back");
            String c = scanner.nextLine().trim();
            switch (c) {
                case "1" -> categoryManager.printAll();
                case "2" -> {
                    System.out.print("New category: ");
                    categoryManager.addCategory(scanner.nextLine().trim());
                }
                case "3" -> {
                    System.out.print("Category to remove: ");
                    categoryManager.removeCategory(scanner.nextLine().trim());
                }
                case "0" -> back = true;
                default -> System.out.println("Unknown");
            }
        }
    }

    private void manageBankAccounts() {
        boolean back = false;
        while (!back) {
            System.out.println(
                    "\nBank Manager\n1) List 2) Add 3) View Account 4) Add Funds 5) View Related Accounts 0) Back");
            String c = scanner.nextLine().trim();
            switch (c) {
                case "1" -> bankManager.printAll();
                case "2" -> addBankAccount();
                case "3" -> viewBankAccount();
                case "4" -> addFunds();
                case "5" -> viewRelatedAccounts();
                case "0" -> back = true;
                default -> System.out.println("Unknown");
            }
        }
    }

    private void addBankAccount() {
        try {
            System.out.print("Account ID: ");
            String id = scanner.nextLine().trim();
            System.out.print("Bank name: ");
            String bn = scanner.nextLine().trim();
            System.out.print("Balance: ");
            double bal = Double.parseDouble(scanner.nextLine().trim());
            if (bal < 0) {
                System.out.println("Balance cannot be negative.");
                return;
            }
            BankAccount acc = new BankAccount(id, bn, bal);
            bankManager.addAccount(acc);
            accountsGraph.addVertex(id);
            notifier.add(acc);
            System.out.println("Account added.");
        } catch (NumberFormatException | NullPointerException ex) {
            System.out.println("Error adding account: " + ex.getMessage());
        }
    }

    private void viewBankAccount() {
        System.out.print("Account ID: ");
        BankAccount a = bankManager.getAccount(scanner.nextLine().trim());
        if (a == null)
            System.out.println("Not found");
        else
            System.out.println(a);
    }

    private void addFunds() {
        try {
            System.out.print("Account ID: ");
            String aid = scanner.nextLine().trim();
            System.out.print("Amount: ");
            double amt = Double.parseDouble(scanner.nextLine().trim());
            if (amt <= 0) {
                System.out.println("Amount must be positive.");
                return;
            }
            BankAccount aa = bankManager.getAccount(aid);
            if (aa != null) {
                aa.addBalance(amt);
                notifier.update(aa);
                System.out.println("Added funds.");
            } else {
                System.out.println("Not found.");
            }
        } catch (NumberFormatException | NullPointerException ex) {
            System.out.println("Error adding funds: " + ex.getMessage());
        }
    }

    private void viewRelatedAccounts() {
        System.out.print("Account ID: ");
        String id = scanner.nextLine().trim();
        accountsGraph.neighbors(id).forEach(n -> System.out.println(" - Related: " + n));
    }

    private void searchAndSortMenu() {
        boolean back = false;
        while (!back) {
            System.out.println(
                    "\nSearch & Sort\n1) Sort by Category (alpha)\n2) Sort by Date (chronological)\n3) Search by Time Range\n4) Search by Category\n5) Search by Cost Range\n6) Search by Bank Account\n0) Back");
            String c = scanner.nextLine().trim();
            switch (c) {
                case "1":
                    searchSort.mergeSortByCategory(store.values()).forEach(System.out::println);
                    break;
                case "2":
                    searchSort.mergeSortByDate(store.values()).forEach(System.out::println);
                    break;
                case "3":
                    searchByTimeRange();
                    break;
                case "4":
                    searchByCategory();
                    break;
                case "5":
                    searchByCostRange();
                    break;
                case "6":
                    searchByAccount();
                    break;
                case "0":
                    back = true;
                    break;
                default:
                    System.out.println("Unknown");
            }
        }
    }

    private void searchByTimeRange() {
        try {
            System.out.print("From (yyyy-MM-dd): ");
            LocalDate f = LocalDate.parse(scanner.nextLine().trim(), DF);
            System.out.print("To (yyyy-MM-dd): ");
            LocalDate t = LocalDate.parse(scanner.nextLine().trim(), DF);
            searchSort.searchByTimeRange(store.values(), f, t).forEach(System.out::println);
        } catch (DateTimeParseException | NullPointerException ex) {
            System.out.println("Bad date");
        }
    }

    private void searchByCategory() {
        System.out.print("Category: ");
        String cat = scanner.nextLine().trim();
        searchSort.searchByCategory(store.values(), cat).forEach(System.out::println);
    }

    private void searchByCostRange() {
        try {
            System.out.print("Min cost: ");
            double lo = Double.parseDouble(scanner.nextLine().trim());
            System.out.print("Max cost: ");
            double hi = Double.parseDouble(scanner.nextLine().trim());
            searchSort.searchByCostRange(store.values(), lo, hi).forEach(System.out::println);
        } catch (NumberFormatException ex) {
            System.out.println("Invalid number format: " + ex.getMessage());
        } catch (IllegalArgumentException ex) {
            System.out.println("Invalid cost range: " + ex.getMessage());
        }
    }

    private void searchByAccount() {
        System.out.print("Account ID: ");
        String aid = scanner.nextLine().trim();
        searchSort.searchByAccount(store.values(), aid).forEach(System.out::println);
    }

    private void processReceiptQueue() {
        System.out.println("Processing receipt upload queue.\n1) Process next 2) View Queue 0) Back");
        String c = scanner.nextLine().trim();
        switch (c) {
            case "1" -> {
                Receipt r = receiptQueue.dequeue();
                if (r == null)
                    System.out.println("Queue empty");
                else
                    System.out.println("Processed receipt for " + r.getExpCode() + ", file: " + r.getFilename());
            }
            case "2" -> receiptQueue.printAll();
            case "0" -> {
                // Do nothing, just return
            }
            default -> System.out.println("Unknown");
        }
    }

    private void processReceiptStack() {
        System.out.println("Processing receipt review stack.\n1) Review top 2) View Stack 0) Back");
        String c = scanner.nextLine().trim();
        switch (c) {
            case "1" -> {
                Receipt r = receiptStack.pop();
                if (r == null)
                    System.out.println("Stack empty");
                else
                    System.out.println("Reviewed receipt for " + r.getExpCode() + ", file: " + r.getFilename());
            }
            case "2" -> receiptStack.printAll();
            case "0" -> {
                // Do nothing, just return
            }
            default -> System.out.println("Unknown");
        }
    }

    private void showCashFlowAnalysis() {
        analyzer.analyze(store.values(), bankManager.getAllAccounts());
    }
}