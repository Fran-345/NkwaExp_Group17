import java.time.LocalDate;

public class Receipt {
    private final String expCode;
    private final String filename;
    private final LocalDate uploadedAt;

    public Receipt(String expCode, String filename, LocalDate uploadedAt) {
        this.expCode = expCode;
        this.filename = filename;
        this.uploadedAt = uploadedAt;
    }

    public String getExpCode() {
        return expCode;
    }

    public String getFilename() {
        return filename;
    }

    public LocalDate getUploadedAt() {
        return uploadedAt;
    }

    @Override
    public String toString() {
        return "Receipt for " + expCode + ", file: " + filename + ", uploaded: " + uploadedAt;
    }
}