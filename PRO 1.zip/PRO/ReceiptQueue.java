public class ReceiptQueue {
    private final SimpleQueue<Receipt> q = new SimpleQueue<>();

    public void enqueue(Receipt r) {
        q.enqueue(r);
    }

    public Receipt dequeue() {
        return q.dequeue();
    }

    public void printAll() {
        q.printAll();
    }
}