public class ReceiptStack {
    private final SimpleStack<Receipt> stack = new SimpleStack<>(16);

    public void push(Receipt r) {
        stack.push(r);
    }

    public Receipt pop() {
        return stack.pop();
    }

    public void printAll() {
        if (stack.peek() == null) {
            System.out.println("Stack empty");
        } else {
            System.out.println("Receipt Stack:");
            stack.printAll();
        }
    }
}