import java.time.LocalDate;
import java.util.*;

public class SearchSortUtils {
    public List<Expenditure> mergeSortByCategory(List<Expenditure> list) {
        List<Expenditure> copy = new ArrayList<>(list);
        if (copy.size() < 2)
            return copy;
        mergeSortCategory(copy, 0, copy.size() - 1);
        return copy;
    }

    private void mergeSortCategory(List<Expenditure> a, int l, int r) {
        if (l >= r)
            return;
        int m = (l + r) / 2;
        mergeSortCategory(a, l, m);
        mergeSortCategory(a, m + 1, r);
        List<Expenditure> tmp = new ArrayList<>();
        int i = l, j = m + 1;
        while (i <= m && j <= r) {
            if (a.get(i).getCategory().compareToIgnoreCase(a.get(j).getCategory()) <= 0)
                tmp.add(a.get(i++));
            else
                tmp.add(a.get(j++));
        }
        while (i <= m)
            tmp.add(a.get(i++));
        while (j <= r)
            tmp.add(a.get(j++));
        for (int k = 0; k < tmp.size(); k++)
            a.set(l + k, tmp.get(k));
    }

    public List<Expenditure> mergeSortByDate(List<Expenditure> list) {
        List<Expenditure> copy = new ArrayList<>(list);
        if (copy.size() < 2)
            return copy;
        mergeSortDate(copy, 0, copy.size() - 1);
        return copy;
    }

    private void mergeSortDate(List<Expenditure> a, int l, int r) {
        if (l >= r)
            return;
        int m = (l + r) / 2;
        mergeSortDate(a, l, m);
        mergeSortDate(a, m + 1, r);
        List<Expenditure> tmp = new ArrayList<>();
        int i = l, j = m + 1;
        while (i <= m && j <= r) {
            if (a.get(i).getDate().isBefore(a.get(j).getDate()) || a.get(i).getDate().isEqual(a.get(j).getDate()))
                tmp.add(a.get(i++));
            else
                tmp.add(a.get(j++));
        }
        while (i <= m)
            tmp.add(a.get(i++));
        while (j <= r)
            tmp.add(a.get(j++));
        for (int k = 0; k < tmp.size(); k++)
            a.set(l + k, tmp.get(k));
    }

    public List<Expenditure> searchByTimeRange(List<Expenditure> list, LocalDate from, LocalDate to) {
        List<Expenditure> r = new ArrayList<>();
        for (Expenditure e : list) {
            if (!e.getDate().isBefore(from) && !e.getDate().isAfter(to))
                r.add(e);
        }
        return r;
    }

    public List<Expenditure> searchByCategory(List<Expenditure> list, String cat) {
        List<Expenditure> r = new ArrayList<>();
        for (Expenditure e : list) {
            if (e.getCategory().equalsIgnoreCase(cat))
                r.add(e);
        }
        return r;
    }

    public List<Expenditure> searchByCostRange(List<Expenditure> list, double lo, double hi) {
        List<Expenditure> r = new ArrayList<>();
        for (Expenditure e : list) {
            if (e.getAmount() >= lo && e.getAmount() <= hi)
                r.add(e);
        }
        return r;
    }

    public List<Expenditure> searchByAccount(List<Expenditure> list, String acc) {
        List<Expenditure> r = new ArrayList<>();
        for (Expenditure e : list) {
            if (e.getAccountUsed().equalsIgnoreCase(acc))
                r.add(e);
        }
        return r;
    }
}