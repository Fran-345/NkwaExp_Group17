public class SimpleLinkedList<T> {
    class Node {
        T val;
        Node next;

        Node(T v) {
            val = v;
        }
    }

    private Node head;

    public void add(T v) {
        Node n = new Node(v);
        if (head == null)
            head = n;
        else {
            Node cur = head;
            while (cur.next != null)
                cur = cur.next;
            cur.next = n;
        }
    }

    public boolean remove(T v) {
        if (head == null)
            return false;
        if (head.val.equals(v)) {
            head = head.next;
            return true;
        }
        Node cur = head;
        while (cur.next != null) {
            if (cur.next.val.equals(v)) {
                cur.next = cur.next.next;
                return true;
            }
            cur = cur.next;
        }
        return false;
    }

    public int size() {
        int count = 0;
        Node cur = head;
        while (cur != null) {
            count++;
            cur = cur.next;
        }
        return count;
    }
}