import java.util.LinkedList;

public class SimpleQueue<T> {
    private final LinkedList<T> list = new LinkedList<>();

    public void enqueue(T v) {
        list.addLast(v);
    }

    public T dequeue() {
        return list.isEmpty() ? null : list.removeFirst();
    }

    public void printAll() {
        if (list.isEmpty())
            System.out.println("Queue empty");
        else {
            for (T x : list)
                System.out.println(" - " + x.toString());
        }
    }
}