
// Added explicit import for Objects
import java.util.*;

public class SimpleSet<T> {
    private Object[] arr = new Object[16];
    private int size = 0;

    public boolean add(T v) {
        if (contains(v))
            return false;
        if (size == arr.length)
            arr = Arrays.copyOf(arr, arr.length * 2);
        arr[size++] = v;
        return true;
    }

    public boolean remove(T v) {
        for (int i = 0; i < size; i++) {
            if (Objects.equals(arr[i], v)) {
                arr[i] = arr[size - 1];
                arr[size - 1] = null;
                size--;
                return true;
            }
        }
        return false;
    }

    public boolean contains(T v) {
        for (int i = 0; i < size; i++) {
            if (Objects.equals(arr[i], v))
                return true;
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    public List<T> items() {
        List<T> out = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            out.add((T) arr[i]);
        }
        return out;
    }
}