import java.util.Arrays;

public class SimpleStack<T> {
    private Object[] arr;
    private int top = -1;

    public SimpleStack(int cap) {
        arr = new Object[cap];
    }

    public void push(T v) {
        if (top + 1 == arr.length)
            arr = Arrays.copyOf(arr, arr.length * 2);
        arr[++top] = v;
    }

    @SuppressWarnings("unchecked") // Suppress unchecked cast warning
    public T pop() {
        if (top < 0)
            return null;
        T v = (T) arr[top];
        arr[top--] = null;
        return v;
    }

    @SuppressWarnings("unchecked") // Suppress unchecked cast warning
    public T peek() {
        return top < 0 ? null : (T) arr[top];
    }

    public void printAll() {
        for (int i = top; i >= 0; i--) {
            System.out.println(" - " + arr[i].toString());
        }
    }
}
