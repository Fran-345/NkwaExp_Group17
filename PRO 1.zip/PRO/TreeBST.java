public class TreeBST {
    private Node root;

    static class Node {
        Expenditure val;
        Node left, right;

        Node(Expenditure v) {
            val = v;
        }
    }

    public void insert(Expenditure e) {
        root = insertRec(root, e);
    }

    private Node insertRec(Node cur, Expenditure e) {
        if (cur == null)
            return new Node(e);
        int cmp = e.getCode().compareTo(cur.val.getCode());
        if (cmp < 0)
            cur.left = insertRec(cur.left, e);
        else if (cmp > 0)
            cur.right = insertRec(cur.right, e);
        else
            cur.val = e;
        return cur;
    }

    public Expenditure find(String code) {
        Node n = findRec(root, code);
        return n == null ? null : n.val;
    }

    private Node findRec(Node cur, String code) {
        if (cur == null)
            return null;
        int cmp = code.compareTo(cur.val.getCode());
        if (cmp == 0)
            return cur;
        else if (cmp < 0)
            return findRec(cur.left, code);
        else
            return findRec(cur.right, code);
    }
}